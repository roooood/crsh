import React from 'react';

const Context = React.createContext({ game: null, state: {} });
export default Context;
